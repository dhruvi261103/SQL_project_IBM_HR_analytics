Satisfaction Classification:
Segments employees based on satisfaction levels, allowing HR to focus on improving low-satisfaction areas.



SELECT 
    employeenumber,
    jobsatisfaction,
    CASE 
        WHEN jobsatisfaction >= 4 THEN 'High'
        WHEN jobsatisfaction = 3 THEN 'Medium'
        ELSE 'Low'
    END AS satisfaction_level
FROM employees;