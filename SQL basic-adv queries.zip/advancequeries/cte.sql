Identify High Earners within Departments:
Detects employees earning above average in their respective departments, facilitating merit-based compensation planning.

WITH dept_stats AS (
    SELECT 
        department,
        AVG(monthlyincome) AS avg_salary
    FROM employees
    GROUP BY department
)
SELECT 
    e.employeenumber,
    e.department,
    e.monthlyincome,
    d.avg_salary
FROM employees e
JOIN dept_stats d ON e.department = d.department
WHERE e.monthlyincome > d.avg_salary;