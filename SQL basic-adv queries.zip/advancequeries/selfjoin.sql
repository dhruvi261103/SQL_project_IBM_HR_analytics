Manager-Employee Relationships:
Creates a reporting hierarchy to identify reporting structures, which is useful for organizational restructuring.


ALTER TABLE employees ADD COLUMN manager_id INT REFERENCES employees(employeenumber);


UPDATE employees SET manager_id = 100 WHERE employeenumber IN (101, 102);
UPDATE employees SET manager_id = 101 WHERE employeenumber = 103;

SELECT 
    e1.employeenumber AS emp_id,
    e2.employeenumber AS manager_id
FROM employees e1
LEFT JOIN employees e2 ON e1.manager_id = e2.employeenumber;
