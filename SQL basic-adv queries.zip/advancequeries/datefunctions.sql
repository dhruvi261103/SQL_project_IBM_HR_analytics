Employee Tenure Analysis:
Identifies recently hired employees, assisting in retention strategies and probation period evaluations.


ALTER TABLE employees ADD COLUMN hire_date DATE;

UPDATE employees 
SET hire_date = CURRENT_DATE - (yearsatcompany * 365 * INTERVAL '1 day');

SELECT employeenumber, hire_date 
FROM employees 
WHERE hire_date > CURRENT_DATE - INTERVAL '5 years';
