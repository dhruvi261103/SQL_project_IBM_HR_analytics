Income Ranking per Department:
Ranks employees by income within departments, enabling internal equity reviews and merit-based promotions.

SELECT 
    employeenumber,
    department,
    monthlyincome,
    RANK() OVER (PARTITION BY department ORDER BY monthlyincome DESC) AS dept_rank
FROM employees;