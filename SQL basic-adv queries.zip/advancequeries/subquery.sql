Identify High Earners:
Detects employees earning above the average, helping in identifying potential outliers for pay adjustment.

SELECT employeenumber, monthlyincome 
FROM employees 
WHERE monthlyincome > (SELECT AVG(monthlyincome) FROM employees);