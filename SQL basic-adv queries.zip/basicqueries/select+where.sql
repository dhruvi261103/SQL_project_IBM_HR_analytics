Identify Employees by Department:

SELECT employeenumber, age, department 
FROM employees 
WHERE department = 'Sales';