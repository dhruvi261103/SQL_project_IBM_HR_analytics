Identify Top Earners:
Helps management identify high-income employees for compensation reviews or leadership grooming.

SELECT employeenumber, monthlyincome 
FROM employees 
ORDER BY monthlyincome DESC 
LIMIT 10;