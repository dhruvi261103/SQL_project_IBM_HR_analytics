Salary Range Analysis:
Identifies employees falling within a certain salary bracket, assisting in compensation analysis and pay equity audits.


SELECT employeenumber, monthlyincome 
FROM employees 
WHERE monthlyincome BETWEEN 5000 AND 10000;