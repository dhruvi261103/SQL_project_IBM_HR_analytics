Workforce Distribution Analysis:
Detects departments with a high number of employees, helping HR manage workload and optimize headcount.


SELECT department, COUNT(*) 
FROM employees 
GROUP BY department 
HAVING COUNT(*) > 50;