Salary Normalization:
Converts salary into a readable format for better financial analysis and reporting.

SELECT employeenumber, CAST(monthlyincome AS FLOAT)/1000 AS salary_in_k 
FROM employees;