List of Departments:

SELECT DISTINCT department FROM employees;