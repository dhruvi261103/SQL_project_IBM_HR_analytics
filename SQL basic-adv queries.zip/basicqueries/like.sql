Identify Managers or Leadership Roles:
Helps HR filter out managerial positions, aiding in succession planning and leadership development.


SELECT employeenumber, jobrole 
FROM employees 
WHERE jobrole LIKE '%Manager%';