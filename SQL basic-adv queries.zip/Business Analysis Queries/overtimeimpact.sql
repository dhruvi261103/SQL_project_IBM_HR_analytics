Impact of Overtime on Work-Life Balance and Attrition:
Evaluates the impact of overtime on work-life balance and attrition rates, informing policies for overtime management.


SELECT 
    overtime,
    AVG(worklifebalance) AS avg_work_life_balance,
    ROUND(100.0 * SUM(CASE WHEN attrition = 'Yes' THEN 1 ELSE 0 END) / COUNT(*), 2) AS attrition_rate
FROM employees
GROUP BY overtime;