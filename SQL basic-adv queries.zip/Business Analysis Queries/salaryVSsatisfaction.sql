Correlation Between Salary and Satisfaction:
Helps assess the relationship between salary and job satisfaction to identify areas for improvement.

SELECT 
    jobsatisfaction,
    AVG(monthlyincome)::INT AS avg_salary,
    COUNT(*) AS employees
FROM employees
GROUP BY jobsatisfaction
ORDER BY jobsatisfaction;